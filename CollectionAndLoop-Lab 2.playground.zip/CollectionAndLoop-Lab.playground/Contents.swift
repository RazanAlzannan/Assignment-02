import Foundation

// Create empty array of type Int
var array0 : [Int] = []
// add five values to the array
array0 += [1,2,3,4,5]
print(array0)
print("--------")
// Use a for-in loop to iterate through the array
for i in array0 {
    print(i)
}
print("--------")
// Create a dictionary with string keys and integer values
var Dictionary0 : [String : Int ] = ["A": 100,"B": 95]
// Use a for-in loop to iterate through the dictionary
for i in Dictionary0{
    print(i)
}
print("--------")
// Create a while loop that counts up to 100
var count : Int = 0
while(count < 100){
  count += 1
  print(count)
}
print("--------")
// Create a repeat-while loop that counts down from 10
var count2 = 10
repeat {
    print(count2)
    count2 -= 1
}while(count2 > 0)
print("--------")
// Use a for-in loop to iterate through a range of numbers
for i in 0...5{
    print(i)
}

// Use a for-in loop to iterate through a range of numbers with a step
//: OUTPUT
/*
 0
 2
 4
 6
 8
 */
print("--------")
for i in stride(from: 0, to: 9, by: 2) {
    print(i)
}
print("--------")
// Create an array of strings and use a for-in loop to print each one
let arr14 : [String] = ["Razan", "Reema", "Rana", "Elaf"]
for i in arr14 {
    print(i)
}
print("--------")
// Use a for-in loop with the enumerated() method to iterate through an array and print the index and value of each element
for (index, name) in arr14.enumerated() {
    print("\(index): \(name)")
}
print("--------")

/*
 Write a swift program to formulate this shape
 😃
 😃😃
 😃😃😃
 😃😃😃😃
 😃😃😃😃😃
 */

var row = 0
repeat {
    if(row >= 0){
        for _ in 0...row{
            print("😃", terminator: "")
        }
        print("\n")
    }
    row += 1
}while(row<5)
